﻿namespace TrabalhoFinalDeModulo10
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.text1 = new System.Windows.Forms.Label();
            this.text2 = new System.Windows.Forms.Label();
            this.CaixaDeTexto1 = new System.Windows.Forms.MaskedTextBox();
            this.text3 = new System.Windows.Forms.Label();
            this.CaixaDeTexto2 = new System.Windows.Forms.MaskedTextBox();
            this.CaixaDeTexto3 = new System.Windows.Forms.MaskedTextBox();
            this.text4 = new System.Windows.Forms.Label();
            this.text5 = new System.Windows.Forms.Label();
            this.CaixaDeTexto4 = new System.Windows.Forms.MaskedTextBox();
            this.Butt1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DepositarVlrs = new System.Windows.Forms.MaskedTextBox();
            this.LevantarVlrs = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.text7 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.LstMovimentos1 = new System.Windows.Forms.ListBox();
            this.Dinheiro = new System.Windows.Forms.Label();
            this.Dinheiro_ = new System.Windows.Forms.Label();
            this.btn_Saida = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // text1
            // 
            this.text1.AutoSize = true;
            this.text1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text1.Location = new System.Drawing.Point(632, 60);
            this.text1.Name = "text1";
            this.text1.Size = new System.Drawing.Size(94, 20);
            this.text1.TabIndex = 1;
            this.text1.Text = "Movimentos";
            // 
            // text2
            // 
            this.text2.AutoSize = true;
            this.text2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text2.Location = new System.Drawing.Point(114, 60);
            this.text2.Name = "text2";
            this.text2.Size = new System.Drawing.Size(109, 20);
            this.text2.TabIndex = 2;
            this.text2.Text = "Nome cliente: ";
            // 
            // CaixaDeTexto1
            // 
            this.CaixaDeTexto1.Location = new System.Drawing.Point(118, 83);
            this.CaixaDeTexto1.Name = "CaixaDeTexto1";
            this.CaixaDeTexto1.Size = new System.Drawing.Size(151, 20);
            this.CaixaDeTexto1.TabIndex = 3;
            this.CaixaDeTexto1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CaixaDeTexto1_KeyPress);
            // 
            // text3
            // 
            this.text3.AutoSize = true;
            this.text3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text3.Location = new System.Drawing.Point(114, 113);
            this.text3.Name = "text3";
            this.text3.Size = new System.Drawing.Size(133, 20);
            this.text3.TabIndex = 4;
            this.text3.Text = "Profissão cliente: ";
            // 
            // CaixaDeTexto2
            // 
            this.CaixaDeTexto2.Location = new System.Drawing.Point(118, 147);
            this.CaixaDeTexto2.Name = "CaixaDeTexto2";
            this.CaixaDeTexto2.Size = new System.Drawing.Size(151, 20);
            this.CaixaDeTexto2.TabIndex = 5;
            // 
            // CaixaDeTexto3
            // 
            this.CaixaDeTexto3.Location = new System.Drawing.Point(118, 221);
            this.CaixaDeTexto3.Name = "CaixaDeTexto3";
            this.CaixaDeTexto3.Size = new System.Drawing.Size(151, 20);
            this.CaixaDeTexto3.TabIndex = 6;
            // 
            // text4
            // 
            this.text4.AutoSize = true;
            this.text4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text4.Location = new System.Drawing.Point(114, 182);
            this.text4.Name = "text4";
            this.text4.Size = new System.Drawing.Size(93, 20);
            this.text4.TabIndex = 7;
            this.text4.Text = "NIF cliente: ";
            // 
            // text5
            // 
            this.text5.AutoSize = true;
            this.text5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text5.Location = new System.Drawing.Point(113, 257);
            this.text5.Name = "text5";
            this.text5.Size = new System.Drawing.Size(110, 20);
            this.text5.TabIndex = 8;
            this.text5.Text = "Conta cliente: ";
            // 
            // CaixaDeTexto4
            // 
            this.CaixaDeTexto4.Location = new System.Drawing.Point(117, 292);
            this.CaixaDeTexto4.Name = "CaixaDeTexto4";
            this.CaixaDeTexto4.Size = new System.Drawing.Size(151, 20);
            this.CaixaDeTexto4.TabIndex = 9;
            // 
            // Butt1
            // 
            this.Butt1.Location = new System.Drawing.Point(135, 396);
            this.Butt1.Margin = new System.Windows.Forms.Padding(2);
            this.Butt1.Name = "Butt1";
            this.Butt1.Size = new System.Drawing.Size(103, 45);
            this.Butt1.TabIndex = 10;
            this.Butt1.Text = "Reniciar";
            this.Butt1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(478, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Levantar Valor: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(314, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "Depositar Valor: ";
            // 
            // DepositarVlrs
            // 
            this.DepositarVlrs.Location = new System.Drawing.Point(318, 147);
            this.DepositarVlrs.Name = "DepositarVlrs";
            this.DepositarVlrs.Size = new System.Drawing.Size(115, 20);
            this.DepositarVlrs.TabIndex = 13;
            this.DepositarVlrs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DepositarVlrs_KeyPress);
            // 
            // LevantarVlrs
            // 
            this.LevantarVlrs.Location = new System.Drawing.Point(470, 147);
            this.LevantarVlrs.Name = "LevantarVlrs";
            this.LevantarVlrs.Size = new System.Drawing.Size(115, 20);
            this.LevantarVlrs.TabIndex = 14;
            this.LevantarVlrs.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.LevantarVlrs_MaskInputRejected);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(309, 1);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(6, 6);
            this.button1.TabIndex = 15;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(318, 182);
            this.btn2.Margin = new System.Windows.Forms.Padding(2);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(266, 45);
            this.btn2.TabIndex = 16;
            this.btn2.Text = "Inserir Valores";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(2, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "Data de abertura: ";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // text7
            // 
            this.text7.AutoSize = true;
            this.text7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text7.Location = new System.Drawing.Point(118, 326);
            this.text7.Name = "text7";
            this.text7.Size = new System.Drawing.Size(128, 20);
            this.text7.TabIndex = 18;
            this.text7.Text = "Saldo Utilizador: ";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(117, 359);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(151, 20);
            this.maskedTextBox1.TabIndex = 19;
            // 
            // LstMovimentos1
            // 
            this.LstMovimentos1.FormattingEnabled = true;
            this.LstMovimentos1.Location = new System.Drawing.Point(621, 98);
            this.LstMovimentos1.Margin = new System.Windows.Forms.Padding(2);
            this.LstMovimentos1.Name = "LstMovimentos1";
            this.LstMovimentos1.Size = new System.Drawing.Size(119, 290);
            this.LstMovimentos1.TabIndex = 21;
            this.LstMovimentos1.SelectedIndexChanged += new System.EventHandler(this.LstMovimentos1_SelectedIndexChanged);
            // 
            // Dinheiro
            // 
            this.Dinheiro.AutoSize = true;
            this.Dinheiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dinheiro.Location = new System.Drawing.Point(406, 41);
            this.Dinheiro.Name = "Dinheiro";
            this.Dinheiro.Size = new System.Drawing.Size(0, 20);
            this.Dinheiro.TabIndex = 22;
            // 
            // Dinheiro_
            // 
            this.Dinheiro_.AutoSize = true;
            this.Dinheiro_.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dinheiro_.Location = new System.Drawing.Point(314, 21);
            this.Dinheiro_.Name = "Dinheiro_";
            this.Dinheiro_.Size = new System.Drawing.Size(138, 20);
            this.Dinheiro_.TabIndex = 23;
            this.Dinheiro_.Text = "Capital Disponivel:";
            this.Dinheiro_.Click += new System.EventHandler(this.Dinheiro__Click);
            // 
            // btn_Saida
            // 
            this.btn_Saida.Location = new System.Drawing.Point(395, 279);
            this.btn_Saida.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Saida.Name = "btn_Saida";
            this.btn_Saida.Size = new System.Drawing.Size(103, 45);
            this.btn_Saida.TabIndex = 24;
            this.btn_Saida.Text = "Sair";
            this.btn_Saida.UseVisualStyleBackColor = true;
            this.btn_Saida.Click += new System.EventHandler(this.btn_Saida_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Saida);
            this.Controls.Add(this.Dinheiro_);
            this.Controls.Add(this.Dinheiro);
            this.Controls.Add(this.LstMovimentos1);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.text7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.LevantarVlrs);
            this.Controls.Add(this.DepositarVlrs);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Butt1);
            this.Controls.Add(this.CaixaDeTexto4);
            this.Controls.Add(this.text5);
            this.Controls.Add(this.text4);
            this.Controls.Add(this.CaixaDeTexto3);
            this.Controls.Add(this.CaixaDeTexto2);
            this.Controls.Add(this.text3);
            this.Controls.Add(this.CaixaDeTexto1);
            this.Controls.Add(this.text2);
            this.Controls.Add(this.text1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label text1;
        private System.Windows.Forms.Label text2;
        private System.Windows.Forms.MaskedTextBox CaixaDeTexto1;
        private System.Windows.Forms.Label text3;
        private System.Windows.Forms.MaskedTextBox CaixaDeTexto2;
        private System.Windows.Forms.MaskedTextBox CaixaDeTexto3;
        private System.Windows.Forms.Label text4;
        private System.Windows.Forms.Label text5;
        private System.Windows.Forms.MaskedTextBox CaixaDeTexto4;
        private System.Windows.Forms.Button Butt1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox DepositarVlrs;
        private System.Windows.Forms.MaskedTextBox LevantarVlrs;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label text7;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.ListBox LstMovimentos1;
        private System.Windows.Forms.Label Dinheiro;
        private System.Windows.Forms.Label Dinheiro_;
        private System.Windows.Forms.Button btn_Saida;
    }
}